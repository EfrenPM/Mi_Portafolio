<script setup lang="ts">
  import { RouterLink, RouterView, useRoute } from 'vue-router';
  
  const route = useRoute();
  </script>
  
  <template>
    <!-- Contenedor principal con el fondo azul oscuro profesional -->
    <div class="min-h-screen bg-slate-900 text-slate-100 font-sans flex flex-col">
      
      <!-- Header / Navbar -->
      <header class="bg-slate-800/50 backdrop-blur-md border-b border-slate-700 sticky top-0 z-50">
        <nav class="container mx-auto px-6 py-4 flex justify-start items-center">
  <!-- Logo con margen a la derecha (mr-10) para separar los botones -->
  <router-link to="/about" class="text-2xl font-bold tracking-tighter hover:text-blue-400 transition-colors mr-10">
    SAÚL<span class="text-blue-500">.DEV</span>
  </router-link>

  <!-- Enlaces alineados a la izquierda gracias al justify-start del padre -->
  <div class="hidden md:flex items-center space-x-1">
    <router-link to="/about" class="px-4 py-2 rounded-lg text-slate-300 hover:text-blue-400 hover:bg-slate-700/50 transition-all duration-300 text-sm font-medium">Sobre mí</router-link>
    <router-link to="/projects" class="px-4 py-2 rounded-lg text-slate-300 hover:text-blue-400 hover:bg-slate-700/50 transition-all duration-300 text-sm font-medium">Proyectos</router-link>
    <router-link to="/skills" class="px-4 py-2 rounded-lg text-slate-300 hover:text-blue-400 hover:bg-slate-700/50 transition-all duration-300 text-sm font-medium">Habilidades</router-link>
    <router-link to="/experience" class="px-4 py-2 rounded-lg text-slate-300 hover:text-blue-400 hover:bg-slate-700/50 transition-all duration-300 text-sm font-medium">Experiencia</router-link>
    <router-link to="/contact" class="px-4 py-2 rounded-lg text-slate-300 hover:text-blue-400 hover:bg-slate-700/50 transition-all duration-300 text-sm font-medium">Contacto</router-link>
  </div>
</nav>
      </header>
  
      <!-- Cuerpo de la aplicación -->
      <main class="flex-grow w-full bg-slate-900">
        <router-view v-slot="{ Component }">
          <!-- 'out-in' evita que los componentes choquen, 'appear' para la carga inicial -->
          <!-- La :key="$route.path" soluciona el error de tener que recargar la página -->
          <transition name="fade" mode="out-in" appear>
            <div :key="route.path">
              <component :is="Component" />
            </div>
          </transition>
        </router-view>
      </main>
  
      <!-- Footer sencillo -->
      <footer class="py-8 border-t border-slate-800 text-center text-slate-500 text-sm">
        <p>&copy; 2026 Saúl - Portafolio Personal desarrollado con Vue 3</p>
      </footer>
    </div>
  </template>
  
