<script setup lang="ts">
    import type { ITarjetaHabilidad } from '../models/CV';
    
    defineProps<{ habilidad: ITarjetaHabilidad }>();
    </script>
    
    <template>
      <div class="bg-slate-800/50 border border-slate-700 p-5 rounded-xl flex flex-col items-center shadow-lg">
        <div class="w-12 h-12 bg-blue-900/30 rounded-lg flex items-center justify-center mb-4">
          <i :class="[habilidad.logo, 'text-2xl text-blue-400']"></i>
        </div>
        <h3 class="font-bold text-slate-100 mb-1">{{ habilidad.nombre }}</h3>
        <p class="text-xs text-slate-400 mb-4 h-8 text-center">{{ habilidad.descripcion }}</p>
        
        <div class="w-full bg-slate-700 rounded-full h-1.5 mb-2">
          <div class="bg-blue-500 h-1.5 rounded-full" :style="{ width: habilidad.nivel + '%' }"></div>
        </div>
        <span class="text-[10px] uppercase tracking-wider text-blue-400 font-bold">{{ habilidad.nivel }}% Nivel</span>
      </div>
    </template>
    