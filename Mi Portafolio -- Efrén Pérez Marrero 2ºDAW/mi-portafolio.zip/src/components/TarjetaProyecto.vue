<script setup lang="ts">
  import type { ITarjetaProyecto } from '../models/CV';
  
  defineProps<{ proyecto: ITarjetaProyecto }>();
  </script>
  
  <template>
    <div class="bg-slate-800 border border-slate-700 rounded-xl p-6 hover:border-blue-500 transition-all group shadow-xl">
      <h3 class="text-xl font-bold text-blue-400 mb-3 group-hover:text-blue-300">{{ proyecto.title }}</h3>
      <p class="text-slate-300 mb-6 leading-relaxed">{{ proyecto.description }}</p>
      <a 
        :href="proyecto.link" 
        target="_blank" 
        class="inline-flex items-center text-sm font-semibold text-blue-400 hover:text-white transition-colors"
      >
        REPOSITORIO GITHUB <i class="pi pi-arrow-right ml-2 text-xs"></i>
      </a>
    </div>
  </template>
  