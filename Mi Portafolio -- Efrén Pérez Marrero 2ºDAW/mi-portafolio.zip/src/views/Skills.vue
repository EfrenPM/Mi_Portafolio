<script setup lang="ts">
  import cvData from '../data/cv.json';
  import TarjetaHabilidad from '../components/TarjetaHabilidad.vue';
  import type { ITarjetaHabilidad } from '../models/CV';
  
  const habilidades = cvData.skills as ITarjetaHabilidad[];
  </script>
  
  <template>
    <section class="min-h-screen bg-slate-900 py-16 px-4">
      <div class="max-w-6xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-blue-500 font-bold tracking-widest uppercase text-sm mb-2">Stack Tecnológico</h2>
          <h1 class="text-4xl font-extrabold text-white">Habilidades y Aptitudes</h1>
        </div>
        
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <TarjetaHabilidad v-for="(s, i) in habilidades" :key="i" :habilidad="s" />
        </div>
      </div>
    </section>
  </template>
  