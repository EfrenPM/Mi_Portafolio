<template>
    <section id="about" class="pt-8">
      <div class="bg-gray-800 p-8 rounded-lg shadow-xl md:flex items-center">
        <!-- Usamos la URL del JSON -->
        <img 
          :src="info.photoUrl" 
          :alt="'Foto de perfil de Saul' + info.name" 
          class="rounded-full h-48 w-48 object-cover md:mr-8 mb-4 md:mb-0 border-4 border-blue-600 shadow-lg"
        />
        <div>
          <h1 class="text-5xl font-extrabold mb-3 text-white">Hola, soy {{ info.name }}</h1>
          <p class="text-blue-400 mb-4 text-xl">{{ info.title }}</p>
          
          <!-- Usamos los párrafos del JSON -->
          <p class="text-gray-400 mb-4" v-html="formatText(info.summaryP1)"></p>
          <p class="text-gray-400 mb-4" v-html="formatText(info.summaryP2)"></p>
          <p class="text-gray-400" v-html="formatText(info.summaryP3)"></p>
        </div>
      </div>
    </section>
  </template>
  
  <script setup>
  import cvData from '../data/cv.json';
  import { ref } from 'vue';
  
  // Usamos ref() para hacer los datos reactivos si fuera necesario
  const info = ref(cvData.personalInfo);
  
  // Función para reemplazar *texto* por <strong>texto</strong> desde el JSON
  const formatText = (text) => {
    return text.replace(/\*(.*?)\*/g, '<strong>$1</strong>');
  };
  </script>
  