<script setup lang="ts">
  import cvData from '../data/cv.json';
  
  const experiencias = cvData.experience;
  const descargarPDF = () => window.print();
  </script>
  
  <template>
    <section class="min-h-screen bg-slate-900 py-16 px-6 text-slate-200">
      <div class="max-w-3xl mx-auto">
        <div class="flex justify-between items-end mb-12">
          <div>
            <h2 class="text-blue-500 font-bold uppercase text-sm">Trayectoria</h2>
            <h1 class="text-4xl font-bold text-white">Experiencia</h1>
          </div>
          <button @click="descargarPDF" class="bg-blue-600 hover:bg-blue-500 text-white px-5 py-2 rounded-lg text-sm font-bold flex items-center transition-all">
            <i class="pi pi-file-pdf mr-2"></i> PDF
          </button>
        </div>
  
        <div class="space-y-8 border-l border-slate-700 ml-4">
          <div v-for="(exp, i) in experiencias" :key="i" class="relative pl-8">
            <div class="absolute -left-[5px] top-2 w-2 h-2 bg-blue-500 rounded-full ring-4 ring-slate-900"></div>
            <h3 class="text-xl font-bold text-white">{{ exp.puesto }}</h3>
            <p class="text-blue-400 font-medium mb-2">{{ exp.empresa }} — <span class="text-slate-500">{{ exp.periodo }}</span></p>
            <p class="text-slate-400 leading-relaxed text-sm">{{ exp.descripcion }}</p>
          </div>
        </div>
  
        <div class="mt-20 p-8 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 text-center">
          <p class="text-slate-400 mb-2">¿Interesado en mi perfil?</p>
          <p class="text-xl font-bold text-white">saul@ejemplo.com</p>
        </div>
      </div>
    </section>
  </template>
  