<template>
  <section class="min-h-screen bg-slate-900 py-16 px-6">
    <div class="max-w-xl mx-auto bg-slate-800 p-10 rounded-2xl border border-slate-700">
      <h1 class="text-3xl font-bold text-white mb-6 text-center">Contacto</h1>
      <form class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-slate-400 mb-1">Nombre</label>
          <input type="text" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Tu nombre">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-400 mb-1">Correo</label>
          <input type="email" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" placeholder="correo@ejemplo.com">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-400 mb-1">Mensaje</label>
          <textarea rows="4" class="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" placeholder="¿En qué puedo ayudarte?"></textarea>
        </div>
        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-lg transition-colors mt-4">
          Enviar Mensaje
        </button>
      </form>
    </div>
  </section>
</template>
