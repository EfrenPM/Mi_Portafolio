<script setup lang="ts">
  import cvData from '../data/cv.json';
  import TarjetaProyecto from '../components/TarjetaProyecto.vue';
  import type { ITarjetaProyecto } from '../models/CV';
  
  const proyectos = cvData.projects as ITarjetaProyecto[];
  </script>
  
  <template>
    <!-- Cambiamos bg-gray-50 por bg-slate-900 -->
    <section class="min-h-screen bg-slate-900 py-16 px-4">
      <div class="max-w-6xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-blue-500 font-bold tracking-widest uppercase text-sm mb-2">Portfolio</h2>
          <h1 class="text-4xl font-extrabold text-white">Mis Proyectos</h1>
        </div>
  
        <!-- Grid con Tailwind -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <TarjetaProyecto 
            v-for="proy in proyectos" 
            :key="proy.id" 
            :proyecto="proy" 
          />
        </div>
      </div>
    </section>
  </template>
  